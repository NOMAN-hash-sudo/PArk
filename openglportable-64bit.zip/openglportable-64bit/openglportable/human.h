#ifndef HUMAN_H
#define HUMAN_H

void drawMan(float x, float y);
void drawWoman(float x, float y);
void drawChild(float x, float y);
void drawHumans();

#endif
