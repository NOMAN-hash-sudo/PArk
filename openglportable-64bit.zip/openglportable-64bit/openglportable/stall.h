#ifndef STALL_H
#define STALL_H

void drawTicketCounter(float x, float y);
void drawIceCreamStall(float x, float y);
void drawLamp(float x, float y);

#endif
