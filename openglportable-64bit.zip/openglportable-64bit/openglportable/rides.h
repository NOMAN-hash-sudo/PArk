#ifndef RIDES_H
#define RIDES_H

void drawFerrisWheel(float x, float y, float scale);
void drawMerryGoRound(float x, float y, float scale);

#endif
