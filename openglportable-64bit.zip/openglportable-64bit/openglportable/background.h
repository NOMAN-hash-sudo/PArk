#ifndef BACKGROUND_H
#define BACKGROUND_H

void drawBackground();
void drawScenery();

#endif
